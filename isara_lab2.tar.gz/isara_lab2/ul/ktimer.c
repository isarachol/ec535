/* Name: Isara Cholaseuk
BU email: isara@bu.edu */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

/****************************************************** //========================================================================
  Prepared by Matthew Yee
  
  Usage:
    ./ltimer [flag] [message]
	 
	-r (read)
	-w (write)
	
  Examples: 
	./ktimer -r
		Print whatever message that the nibbler module is holding

	./ktimer -w ThisIsAMessage
		Write the string "ThisIsAMessage" to the nibbler module
	
******************************************************/

void printManPage(void);

int main(int argc, char **argv) {
	char line[256]; // 256 will be shrunk by mytimer anyway, so leave it for now
	static int max_count = 1;
	
	/* Check to see if the nibbler successfully has mknod run
	   Assumes that nibbler is tied to /dev/nibbler */
	FILE * pFile;
	// printf("b4 open");
	pFile = fopen("/dev/mytimer", "r+"); // open in file_operations // a+ = append and read
	// printf("after open");
	if (pFile==NULL) {
		fputs("mytimer module isn't loaded\n",stderr);
		return -1;
	}

	// Check if in list mode --> read
	if (argc == 2 && strcmp(argv[1], "-l") == 0) {
		int line_count = 0;
		// printf("line_count = %d\n", line_count);
		while (fgets(line, 256, pFile) != NULL) {
			// printf("while fgets ktimer -l\n");
			int msg_len=0; // msg length
			while (line[msg_len] != '>') //printf("%d\n", msg_len);
				msg_len++;
			line[msg_len] = ' '; // change '>' to ' '
			printf("%s\n", line); // display to terminal
			line_count++; // one more line
		}
		if (line_count == 0) { // no line exists
			return 0;
		}
	}
	// Check if in single timer mode () --> write , read
	else if (argc == 4 && strcmp(argv[1], "-s") == 0) {
		// TODO Check the arguments

		// see if the number of existing timers exceed COUNT
		// printf("Writing [sec] %s [msg] %s\n", argv[2], argv[3]);
		char new_line[256];
		char *n_line = new_line;
		char *msg;
		sprintf(n_line, "%s>%s\n", argv[3], argv[2]); // MSG>SEC\n
		// printf("n_line = %s\n", n_line);

		int line_count = 0;
		bool repeated = false;

		while (fgets(line, 256, pFile) != NULL) { // repeated, maybe make another function?
			// printf("In while, ktimer");
			line_count++; // one more line
			int msg_len=0; // msg length
			while (line[msg_len] != '>')
				msg_len++;
			msg = (char*)malloc(msg_len+1); // free it?
			// printf("msg_len+1 = %d\n", msg_len+1);
			memcpy(msg, &line[0], msg_len);
			// printf("[ktimer] %d *msg %s len %d\n", line_count, msg, strlen(msg));
			// printf("[ktimer] %d argv %s len %d\n", line_count, argv[3], strlen(argv[3]));
			if (strcmp(msg,argv[3]) == 0) // timer already exists
			{
				// printf("True!\n");
				repeated = true;
			}
		}
		// see if there exist old timer with the same string
		// if so, update it
		if (repeated)
		{
			printf("The timer %s was updated!\n", msg); // timer_name
		}
		else if (line_count > 0)
		{
			printf("A timer already exists!\n");
			fclose(pFile);
			return 0;
		}

		// if not, add it
		fputs(n_line, pFile);
	}
	// Otherwise invalid
	else {
		printManPage();
	}

	fclose(pFile);
	return 0;
}

void printManPage() {
	printf("Error: invalid use.\n");
	printf(" ktimer [-flag] [message]\n");
	printf(" -l: read existing message(s) from the mytimer module\n");	
	printf(" -s: register a new timer that, after [SEC] seconds, will print the message [MSG]\n");
	printf(" -m: (NOT IMPLEMENTED) change number of active timers to [COUNT]\n");
}
