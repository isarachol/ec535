/* Name: Isara Cholaseuk
BU email: isara@bu.edu */

/* Necessary includes for device drivers */
#include <linux/init.h> /* module_init / exit */
#include <linux/module.h> /* MODULE_LICENSE and maybe param? */
#include <linux/kernel.h> /* printk() */
#include <linux/slab.h> /* kmalloc() */
#include <linux/fs.h> /* everything... file_operation struct */
#include <linux/errno.h> /* error codes */
#include <linux/types.h> /* size_t */
#include <linux/proc_fs.h>
#include <linux/fcntl.h> /* O_ACCMODE */
#include <asm/system_misc.h> /* cli(), *_flags */
#include <linux/uaccess.h>
#include <asm/uaccess.h> /* copy_from/to_user */
#include <linux/jiffies.h> /* for jiffies */
// #include <linux/sched.h> /* already includes 

MODULE_LICENSE("Dual BSD/GPL");

/* Declaration of memory.c functions */ //========================================================================
static int mytimer_open(struct inode *inode, struct file *filp);
static int mytimer_release(struct inode *inode, struct file *filp);
static ssize_t mytimer_read(struct file *filp,
		char *buf, size_t count, loff_t *f_pos);
static ssize_t mytimer_write(struct file *filp,
		const char *buf, size_t count, loff_t *f_pos);
static void mytimer_exit(void);
static int mytimer_init(void);

/* Structure that declares the usual file */
/* access functions */
struct file_operations mytimer_fops = {
	read: mytimer_read,
	write: mytimer_write,
	open: mytimer_open,
	release: mytimer_release
};

/* Declaration of the init and exit functions */
module_init(mytimer_init); //========================================================================
module_exit(mytimer_exit);

static unsigned capacity = 256; // msg only upto 128 characters + 5 from numbers + 3 from formatting round up
static unsigned bite = 256;
static unsigned first_time = 1;

/* Global variables of the driver */
/* Major number */
static int mytimer_major = 61;

/* Buffer to store data */
static char *mytimer_buffer;
// static char *ul_buffer;
/* length of the current message */
static int mytimer_len;

// ================================= Timer stuff =====================================
// struct timer_list 
// {
// 	/* ... */
// 	unsigned long expires;
// 	void (*function)(unsigned long);
// 	unsigned long data;
// }
static unsigned msg_len = 0;
static unsigned long jiffy_init;
static unsigned second=0;
static struct timer_list my_timer;
static void timer_function(struct timer_list * data) // declare timer function prototype , char* + delete data
{
	memset(&mytimer_buffer[msg_len-1], 0, 6); // reset 5 digits of numbers and '>'

	printk(KERN_INFO "%s\n", mytimer_buffer);
	memset(mytimer_buffer, 0, capacity); // reset the buffer
	// memset(ul_buffer, 0, capacity);
	first_time = 1; // reset timer completely
	mytimer_len = 0;
	second = 0;
	msg_len = 0;
	// printk("end timer_function\n");
}

static int mytimer_init(void) 
{
	int result;

	/* Registering device */
	result = register_chrdev(mytimer_major, "mytimer", &mytimer_fops);
	if (result < 0)
	{
		printk(KERN_ALERT
			"mytimer: cannot obtain major number %d\n", mytimer_major);
		return result;
	}

	/* Allocating mytimer for the buffer */
	mytimer_buffer = kmalloc(capacity, GFP_KERNEL); // first slot for copy_from_user, the rest for storage
	if (!mytimer_buffer)
	{ 
		printk(KERN_ALERT "Insufficient kernel memory\n"); 
		result = -ENOMEM;
		goto fail; 
	}
	memset(mytimer_buffer, 0, capacity);
	
	mytimer_len = 0;
	printk(KERN_ALERT "Inserting mytimer module\n"); 

	// Init timer
	timer_setup(&my_timer, timer_function, 0);

	return 0;

fail: 
	mytimer_exit(); 
	return result;
}

static void mytimer_exit(void)
{
	/* Freeing the major number */
	unregister_chrdev(mytimer_major, "mytimer");

	/* Freeing buffer memory */
	if (mytimer_buffer)
	{
		kfree(mytimer_buffer);
	}

	del_timer(&my_timer);
	printk(KERN_ALERT "Removing mytimer module\n");

}

static int mytimer_open(struct inode *inode, struct file *filp)
{
	// printk(KERN_INFO "open called: process id %d, command %s\n",
	// 	current->pid, current->comm);
	/* Success */
	
	// ul_buffer = kmalloc(capacity, GFP_KERNEL);
	// if (!ul_buffer)
	// { 
	// 	printk(KERN_ALERT "Insufficient kernel memory\n");
	// 	kfree(ul_buffer);
	// 	mytimer_exit(); 
	// 	return -ENOMEM;
	// }
	// memset(ul_buffer, 0, capacity);
	return 0;
}

static int mytimer_release(struct inode *inode, struct file *filp)
{
	// printk(KERN_INFO "release called: process id %d, command %s\n",
	// 	current->pid, current->comm);
	/* Success */
	// if (ul_buffer)
	// {
	// 	kfree(ul_buffer);
	// }
	return 0;
}

static ssize_t mytimer_read(struct file *filp, char *buf, 
							size_t count, loff_t *f_pos)
{ 
	int temp;
	int i=0;
	char tbuf[capacity], *tbptr = tbuf;
	// char *ul_buffer;
	// ul_buffer = kmalloc(capacity, GFP_KERNEL);

	// printk(KERN_INFO "mytimer_read called!\n");
	// both read from file and process the time
	/* end of buffer reached */
	// printk(KERN_INFO "check end of buffer\n");
	// printk(KERN_INFO "*f_pos = %lld\n", *f_pos);
	// printk(KERN_INFO "mytimer_len = %d\n", mytimer_len);
	if (*f_pos >= mytimer_len)
	{
		// printk(KERN_INFO "Exceed end of buffer\n");
		return 0;
	}
	// printk(KERN_INFO "CHECK COUNT\n");
	/* do not go over then end */
	if (count > mytimer_len - *f_pos)
		count = mytimer_len - *f_pos;

	/* do not send back more than a bite */
	if (count > bite) count = bite;

	
	printk(KERN_INFO "first_time = %d\n", first_time);

	// show the reminaing time
	if (first_time!=1)
	{
		unsigned remain = second - (jiffies - jiffy_init)/HZ;
		// printk(KERN_INFO "Remain %u\n", remain);
		unsigned digit_num;
		char digit[5];
		printk(KERN_INFO "before while\n");
		while (remain > 0)
		{
			digit[4-i] = (remain % 10) + '0';
			remain = remain/10;
			i++;
			// printk(KERN_INFO "%d\n", i);
		}
		digit_num = i;
		// update mytimer_buffer
		memset(&mytimer_buffer[msg_len], 0, 5); // reset 5 digits of numbers
		// printk(KERN_INFO "before for\n");
		for (i=0; i<digit_num; i++)
		{
			mytimer_buffer[msg_len+i] = digit[5 - digit_num + i];
		}
		printk("%s\n", mytimer_buffer);
	}

	// reformat data
	// for (i=0; i<capacity; i++)
	// {
	// 	ul_buffer[i] = mytimer_buffer[i];
	// }
	// ul_buffer[msg_len-1] = ' '; // replace '>' with ' '
	
	/* Transfering data to user space */
	if (copy_to_user(buf, mytimer_buffer + *f_pos, count)) // mytimer_buffer + *f_pos, output
	{
		// kfree(ul_buffer);
		return -EFAULT;
	}
	// kfree(ul_buffer);

	// tbptr += sprintf(tbptr,								   
	// "read called: process id %d, command %s, count %d, chars ",
	// current->pid, current->comm, count);

	// for (temp = *f_pos; temp < count + *f_pos; temp++)					  
	// 	tbptr += sprintf(tbptr, "%c", mytimer_buffer[temp]);


	// printk(KERN_INFO "%s\n", tbuf);
	
	/* Changing reading position as best suits */ 
	*f_pos += count; 
	return count; 
}

static ssize_t mytimer_write(struct file *filp, const char *buf,
							size_t count, loff_t *f_pos)
{
	//check mytimer_buffer for repeated string as in buf, check how many currently in buffer
	unsigned long jiffy_num = 0;
	int i = 0;
	int j = 0;
	int repeated = -1; // assume not repeated
	char *msg;
	int new_msg_len = 0;
	unsigned new_second = 0;
	int mod_exp_timer = -1;

	// for writing
	int temp;
	char tbuf[256], *tbptr = tbuf;

	char *ul_buffer;
	ul_buffer = kmalloc(capacity, GFP_KERNEL);
	if (!ul_buffer)
	{ 
		printk(KERN_ALERT "Insufficient kernel memory\n");
		mytimer_exit(); 
		return -ENOMEM;
	}
	// printk(KERN_INFO "mytimer_write\n");
	memset(ul_buffer, 0, capacity);

	// start writing process
	// *f_pos = mytimer_len; // start from beginning
	// printk(KERN_INFO "f_pos = %lld\n", f_pos);
	/* end of buffer reached */
	if (*f_pos >= capacity)
	{
		printk(KERN_INFO
			"write called: process id %d, command %s, count %d, buffer full\n",
			current->pid, current->comm, count);
		return -ENOSPC;
	}

	/* do not eat more than a bite */
	if (count > bite) count = bite;

	/* do not go over the end */
	if (count > capacity - *f_pos)
		count = capacity - *f_pos;

	// printk(KERN_INFO "copy_from_user!");
	if (copy_from_user(ul_buffer, buf, count)) //ul_buffer + *f_pos
	{
		printk(KERN_INFO "copy_from_user fail\n");
		return -EFAULT;
	}

	//=============================== extract information
	// printk(KERN_INFO "Test print buf[i] = %s\n", ul_buffer);
	while (ul_buffer[i] != '>')
	{
		//printk(KERN_INFO "%c\n", mytimer_buffer[i]);
		i++;
	}
	//new_buffer[i] = ' '; // replace '>' with space
	i++; // move passed '>'
	// msg_len = i;
	new_msg_len = i;
	msg = (char*)kmalloc(i, GFP_KERNEL);
	// printk(KERN_INFO "Extract msg");
	for (j=0; j<i; j++)
	{
		msg[j] = ul_buffer[j]; // copy of message
	}
	// printk(KERN_INFO "msg = .%s.", msg);
	// int sec_len = count-msg_len; // just for simplicity fo reading
	// char *sec = (char*)malloc(sec_len); //sjrunk down by the whole "msg>" and '\n' + 1 for end of string
	while (ul_buffer[i] != '\n') // first arg = second
	{
		// printk(KERN_INFO "%c\n", new_buffer[i]);
		// sec[i-msg_len] = mytimer_buffer[i];
		new_second = new_second*10 + (ul_buffer[i] - '0'); // shift left in decimal digit
		// printk(KERN_INFO "buffer - '0' in int = %d", new_buffer[i] - '0');
		i++;
	}
	// printk(KERN_INFO "second = %u\n", new_second);
	// printk(KERN_INFO "HZ = %u\n", HZ);
	jiffy_num = new_second * HZ; // HZ = jiffy / second
	// printk(KERN_INFO "Jiffy num = %lu\n", jiffy_num);
	// printk(KERN_INFO "Current jiffies = %lu\n", jiffies);


	if (first_time == 1)
	{
		// printk(KERN_INFO "write first_time\n");
		for (i=0; i<count; i++)
		{
			mytimer_buffer[i] = ul_buffer[i];
		}
		first_time = 0;// no more easy stuff
		msg_len = new_msg_len; // new msg
		mod_exp_timer = 1;
		// struct timer_list mytimer_timer(timer_function, jiffy_num, mytimer_buffer);
		// add_timer(&mytimer_timer);
		// mod_timer(&my_timer, jiffy_init + jiffy_num);
	}
	else
	{
		//=============================== Check replicates
		// printk(KERN_INFO "Not first_time: Check repeated");
		i=0; // reset char index
		while (mytimer_buffer[i] != '>') // check with existing buffer
		{
			// printk(KERN_INFO "buf[i]:msg[i] = %c : %c\n", mytimer_buffer[i], msg[i]);
			if (mytimer_buffer[i] == msg[i]) // check letter by letter
			{
				repeated = 1; // repeated to a timer
			}
			else
			{
				repeated = -1;
				break;
			}
			i++;
		}

		// printk(KERN_INFO "repeated %d (-1 = no, 1 = yes)\n", repeated);
		if (repeated > -1)
		{
			// printk(KERN_INFO "Repeated!\n");
			// set mytimer_buffer[repeated] to new time
			memset(mytimer_buffer, 0, capacity);
			for (i=0; i<6; i++) // change mytimer_buffer
			{
				mytimer_buffer[i] = ul_buffer[i];
			}
			mod_exp_timer = 1;

			// del_timer(&mytimer_timer);
			// static struct timer_list mytimer_timer(timer_function, jiffy_num, mytimer_buffer);
			// call timer on repeated with new second, return?
			// no additional timer, count_cur stays the same
		} // else, mytimer_buffer remains the same
	}
	if (mod_exp_timer > -1) // mod_timer called
	{
		second = new_second;
		jiffy_init = jiffies;
		mod_timer(&my_timer, jiffies + jiffy_num);
	}
	kfree(ul_buffer);

	//========================== start timer stuff ===============================

	// tbptr += sprintf(tbptr,								   
	// 	"write called: process id %d, command %s, count %d, chars ",
	// 	current->pid, current->comm, count);

	// for (temp = *f_pos; temp < count + *f_pos; temp++)					  
	// 	tbptr += sprintf(tbptr, "%c", mytimer_buffer[temp]);

	// printk(KERN_INFO "%s\n", tbuf);

	*f_pos += count;
	mytimer_len = *f_pos;

	return count;
}

// void timer_function(struct timer_list *)
// {
// 	printk(KERN_INFO "Timer finished! %s\n", buf);
// }
